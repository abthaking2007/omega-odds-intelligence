package com.omega.odds.data

data class OddsPoint(val label: String, val home: Float, val draw: Float, val away: Float)

data class FootballMatch(
    val id: String,
    val home: String,
    val away: String,
    val competition: String,
    val status: MatchStatus,
    val minute: String,
    val score: String,
    val homeOdds: String,
    val drawOdds: String,
    val awayOdds: String,
    val history: List<OddsPoint>
)

enum class MatchStatus { LIVE, UPCOMING }

/** Demo data only. Replace with data from a verified odds API via a backend. */
object DemoMatches {
    private val history1 = listOf(
        OddsPoint("-6h", 2.10f, 3.35f, 3.60f),
        OddsPoint("-4h", 2.02f, 3.40f, 3.75f),
        OddsPoint("-2h", 1.96f, 3.45f, 3.88f),
        OddsPoint("-1h", 1.91f, 3.50f, 4.00f),
        OddsPoint("Now", 1.87f, 3.55f, 4.10f)
    )
    private val history2 = listOf(
        OddsPoint("10'", 2.25f, 3.10f, 3.20f),
        OddsPoint("20'", 2.08f, 3.25f, 3.55f),
        OddsPoint("30'", 1.98f, 3.35f, 3.80f),
        OddsPoint("40'", 2.15f, 3.20f, 3.45f),
        OddsPoint("Now", 2.05f, 3.30f, 3.65f)
    )
    val all = listOf(
        FootballMatch("demo-1", "Arsenal", "Chelsea", "Premier League · Angleterre", MatchStatus.LIVE, "LIVE 63'", "1 - 1", "2.05", "3.30", "3.65", history2),
        FootballMatch("demo-2", "Real Madrid", "Barcelona", "La Liga · Espagne", MatchStatus.UPCOMING, "20:00", "VS", "1.87", "3.55", "4.10", history1),
        FootballMatch("demo-3", "Inter", "Juventus", "Serie A · Italie", MatchStatus.UPCOMING, "21:45", "VS", "2.15", "3.10", "3.45", history2)
    )
}
