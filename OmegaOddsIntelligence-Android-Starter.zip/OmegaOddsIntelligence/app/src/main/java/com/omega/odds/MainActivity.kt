package com.omega.odds

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omega.odds.data.DemoMatches
import com.omega.odds.data.FootballMatch
import com.omega.odds.data.MatchStatus

private val Bg = androidx.compose.ui.graphics.Color(0xFF090E18)
private val Panel = androidx.compose.ui.graphics.Color(0xFF141D2B)
private val Muted = androidx.compose.ui.graphics.Color(0xFF8E9BB0)
private val Accent = androidx.compose.ui.graphics.Color(0xFF38D996)
private val Blue = androidx.compose.ui.graphics.Color(0xFF56A5FF)
private val Orange = androidx.compose.ui.graphics.Color(0xFFFFB454)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OmegaApp() }
    }
}

@Composable
private fun OmegaApp() {
    var liveOnly by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<FootballMatch?>(null) }
    val matches = DemoMatches.all.filter { !liveOnly || it.status == MatchStatus.LIVE }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Accent)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(24.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("OMEGA", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("ODDS INTELLIGENCE", color = androidx.compose.ui.graphics.Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Box(Modifier.background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Text("1XBET", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Text("SUIVI DES COTES FOOTBALL", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !liveOnly, onClick = { liveOnly = false }, label = { Text("Tous les matchs") })
                    FilterChip(selected = liveOnly, onClick = { liveOnly = true }, label = { Text("🔴 En direct") })
                }
                Spacer(Modifier.height(4.dp))
                if (selected == null) {
                    Text("${matches.size} matchs", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                        item { DemoBanner() }
                        items(matches) { match -> MatchCard(match) { selected = match } }
                        item {
                            Text("V1 · PROTOTYPE", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 12.dp, bottom = 16.dp).align(Alignment.CenterHorizontally))
                        }
                    }
                } else {
                    DetailScreen(selected!!) { selected = null }
                }
            }
        }
    }
}

@Composable
private fun DemoBanner() {
    Row(Modifier.fillMaxWidth().background(androidx.compose.ui.graphics.Color(0xFF332819), RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("ⓘ", color = Orange, fontSize = 20.sp)
        Spacer(Modifier.width(10.dp))
        Column {
            Text("MODE DÉMONSTRATION", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Les matchs et les cotes affichés sont fictifs. L'API 1xBet n'est pas encore connectée.", color = androidx.compose.ui.graphics.Color(0xFFE2D5C2), fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun MatchCard(match: FootballMatch, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(match.competition, color = Muted, fontSize = 11.sp, modifier = Modifier.weight(1f))
            Text(match.minute, color = if (match.status == MatchStatus.LIVE) Accent else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(match.home, color = androidx.compose.ui.graphics.Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(5.dp))
                Text(match.away, color = androidx.compose.ui.graphics.Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
            Text(match.score, color = if (match.status == MatchStatus.LIVE) Accent else Muted, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OddsPill("1", match.homeOdds, Modifier.weight(1f))
            OddsPill("X", match.drawOdds, Modifier.weight(1f))
            OddsPill("2", match.awayOdds, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Text("Voir l'évolution des cotes  →", color = Blue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun OddsPill(label: String, odds: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Bg, RoundedCornerShape(8.dp)).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Muted, fontSize = 10.sp)
        Spacer(Modifier.height(3.dp))
        Text(odds, color = androidx.compose.ui.graphics.Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun DetailScreen(match: FootballMatch, onBack: () -> Unit) {
    Spacer(Modifier.height(10.dp))
    Text("‹  Retour aux matchs", color = Blue, modifier = Modifier.clickable(onClick = onBack).padding(vertical = 10.dp))
    Text(match.competition, color = Muted, fontSize = 12.sp)
    Text("${match.home} – ${match.away}", color = androidx.compose.ui.graphics.Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
    Text("Marché 1X2 · évolution historique", color = Muted, fontSize = 12.sp)
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        LegendDot("1 · ${match.home}", Accent)
        LegendDot("X · Nul", Blue)
        LegendDot("2 · ${match.away}", Orange)
    }
    Spacer(Modifier.height(8.dp))
    OddsChart(match)
    Spacer(Modifier.height(16.dp))
    Text("VALEURS ACTUELLES", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OddsPill("1 · ${match.home}", match.homeOdds, Modifier.weight(1f))
        OddsPill("X · Nul", match.drawOdds, Modifier.weight(1f))
        OddsPill("2 · ${match.away}", match.awayOdds, Modifier.weight(1f))
    }
    Spacer(Modifier.height(16.dp))
    Text("L'historique réel commencera une fois la source de cotes connectée. Les points du graphique sont des exemples de démonstration.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
}

@Composable
private fun LegendDot(label: String, color: androidx.compose.ui.graphics.Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).background(color, RoundedCornerShape(50)))
        Spacer(Modifier.width(5.dp))
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun OddsChart(match: FootballMatch) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(12.dp)) {
        Canvas(Modifier.fillMaxWidth().height(220.dp)) {
            val values = match.history.flatMap { listOf(it.home, it.draw, it.away) }
            val minV = (values.minOrNull() ?: 1f) - 0.2f
            val maxV = (values.maxOrNull() ?: 5f) + 0.2f
            val left = 12f; val right = size.width - 12f; val top = 16f; val bottom = size.height - 20f
            for (i in 0..4) {
                val y = top + (bottom - top) * i / 4f
                drawLine(Muted.copy(alpha = 0.18f), Offset(left, y), Offset(right, y), strokeWidth = 1f)
            }
            fun drawSeries(valuesForLine: List<Float>, color: androidx.compose.ui.graphics.Color) {
                val pts = valuesForLine.mapIndexed { i, v ->
                    val x = left + (right - left) * i / (valuesForLine.size - 1).coerceAtLeast(1)
                    val y = bottom - ((v - minV) / (maxV - minV)) * (bottom - top)
                    Offset(x, y)
                }
                pts.zipWithNext().forEach { (a, b) -> drawLine(color, a, b, strokeWidth = 3.5f, cap = StrokeCap.Round) }
                pts.forEach { drawCircle(color, radius = 4f, center = it) }
            }
            drawSeries(match.history.map { it.home }, Accent)
            drawSeries(match.history.map { it.draw }, Blue)
            drawSeries(match.history.map { it.away }, Orange)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            match.history.forEach { Text(it.label, color = Muted, fontSize = 10.sp) }
        }
    }
}
