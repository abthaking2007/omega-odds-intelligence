# OMEGA ODDS INTELLIGENCE — Android starter

Prototype Android native (Kotlin + Jetpack Compose) for a football-only 1xBet odds tracker, with pre-match/live tabs, 1X2 odds cards and an odds movement chart.

## Important status
- This is a UI prototype; all match names, scores, odds and chart points are DEMO DATA.
- No live API is connected yet.
- The API provider's current pricing page says new free keys are paused indefinitely; existing free keys may continue working. Do not assume a new free key is available.
- Never put a private provider API key directly in an APK. A small backend/proxy should hold the key and serve only the app's required data.

## Open in Android Studio
1. Unzip the project.
2. Open the `OmegaOddsIntelligence` folder in Android Studio.
3. Use JDK 17 and allow Gradle sync.
4. Run the `app` configuration on an Android device or emulator.

## Planned data integration
A backend should call the chosen provider, normalize football events and 1xBet markets, and expose app-safe endpoints such as:
- `GET /matches?status=upcoming`
- `GET /matches?status=live`
- `GET /matches/{id}/odds-history?market=1x2`
- `POST /alerts`

Record timestamped odds snapshots to a database to build the chart history. An API's current odds response alone does not guarantee historical odds are available.
